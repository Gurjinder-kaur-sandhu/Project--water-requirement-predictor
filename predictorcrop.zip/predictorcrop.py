import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
import random

# ===================== Calculation Logic =====================
def calculate_water(soil, crop, temp, humidity):
    soil_factors = {
        "Sandy": 0.7, "Loamy": 1.0, "Clay": 1.3,
        "Silty": 1.15, "Peaty": 0.85, "Chalky": 0.9
    }
    crop_factors = {
        "Wheat": 1.0, "Rice": 1.8, "Maize": 1.4,
        "Sugarcane": 2.2, "Cotton": 1.6, "Barley": 0.95,
        "Potato": 1.5, "Tomato": 1.3, "Soybean": 1.25
    }

    base = soil_factors.get(soil, 1)
    crop_factor = crop_factors.get(crop, 1)

    # Temperature effect: ideal ~25°C, drop if too low or high
    temp_effect = 1 - abs(temp - 25) / 50  

    # Humidity effect: more humidity = less water needed
    humidity_effect = 1 - (humidity / 120)  

    water = base * crop_factor * temp_effect * humidity_effect * 200  # 200 is scaling
    return round(max(water, 0), 2)

# ===================== Graph Display =====================

 

def show_graphs(water, crop):
    import random
    import matplotlib.pyplot as plt

    max_capacity = 500
    water_for_pie = min(max(water, 0), max_capacity)
    other_factors = max_capacity - water_for_pie

    fig, axs = plt.subplots(1, 3, figsize=(12, 4))

    # Bar chart with multiple days
    days = [f"Day {i}" for i in range(1, 6)]
    water_values = [
        max(water + random.uniform(-0.05, 0.05) * water, 0) 
        for _ in range(5)
    ]
    axs[0].bar(days, water_values, color="blue")
    axs[0].set_ylabel("Liters per sq.m")
    axs[0].set_title(f"Water Requirement for {crop}")

    # Pie chart
    axs[1].pie([water_for_pie, other_factors],
               labels=["Water Needed", "Remaining Capacity"],
               autopct="%1.1f%%",
               colors=["orange", "lightgray"])
    axs[1].set_title(f"Water % for {crop}")

    # Line chart
    axs[2].plot(days, water_values, marker="o", color="green")
    axs[2].set_title("Water Requirement Over 5 Days")
    axs[2].set_xlabel("Days")
    axs[2].set_ylabel("Liters per sq.m")

    plt.tight_layout()
    plt.show(block=False)

# ===================== Submit Action =====================
def on_submit():
    soil = soil_var.get()
    crop = crop_var.get()

    try:
        temp = float(temp_var.get())
        humidity = float(humidity_var.get())
    except ValueError:
        result_label.config(text="Please enter valid numbers for temperature and humidity!", fg="red")
        return

    water = calculate_water(soil, crop, temp, humidity)
    water = max(water, 0)   

    result_label.config(
        text=f"Based on {soil} soil, {crop} crop, {temp}°C temperature and {humidity}% humidity,\n"
             f"the estimated water requirement is {water} liters per sq.m.",
        fg="green"
    )

    show_graphs(water, crop)

# ===================== GUI =====================
root = tk.Tk()
root.title("Water Requirement Calculator")
root.geometry("500x400") 

tk.Label(root, text="Select Soil Type:", font=("Arial", 12)).pack(pady=5)
soil_var = tk.StringVar()
soil_dropdown = ttk.Combobox(root, textvariable=soil_var, values=["Sandy", "Loamy", "Clay", "Silty", "Peaty", "Chalky"])
soil_dropdown.pack()

tk.Label(root, text="Select Crop Type:", font=("Arial", 12)).pack(pady=5)
crop_var = tk.StringVar()
crop_dropdown = ttk.Combobox(root, textvariable=crop_var, values=["Wheat", "Rice", "Maize", "Sugarcane", "Cotton", "Barley", "Potato", "peanut", "Soybean"])
crop_dropdown.pack()

tk.Label(root, text="Enter Temperature (°C):", font=("Arial", 12)).pack(pady=5)
temp_var = tk.StringVar()
tk.Entry(root, textvariable=temp_var).pack()

tk.Label(root, text="Enter Humidity (%):", font=("Arial", 12)).pack(pady=5)
humidity_var = tk.StringVar()
tk.Entry(root, textvariable=humidity_var).pack()

tk.Button(root, text="Calculate", font=("Arial", 12), bg="blue", fg="white", command=on_submit).pack(pady=10)

result_label = tk.Label(root, text="", font=("Arial", 12))
result_label.pack(pady=10)

root.mainloop()
















#python is a simple language
#it is interpreted as well as compiled language
#it is used for development and data analytics
#it have vast library
#it have some tools like flask and scripted 


